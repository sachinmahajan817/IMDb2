import React from "react";

const Shows = () => {
  return (
    <div className="container">
      <h3 className="h3">Tv Shows</h3>
    </div>
  );
};

export default Shows;
